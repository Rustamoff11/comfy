import { useLoaderData } from "react-router-dom";
import { paginationAmount } from "../utils";
function PaginationsContainer() {
  const { meta } = useLoaderData();
  const paginate = meta.pagination.pageCount;
  console.log(paginate);
  return (
    <div>
      <div className="joinmt-8 pb-6 grid grid-cols-2">
      <button className="join-item btn btn-outline">Previous page</button>
        <button className="btn btn-primary join-item  btn-outline ">
          {paginationAmount(paginate)}
        </button>
      <button className="join-item btn btn-outline">Next</button>
      </div>
    </div>
  );
}

export default PaginationsContainer;
