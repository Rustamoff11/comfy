import React from "react";
import {
  Filters,
  PaginationsContainer,
  ProductsContainer,
} from "../components";
import { customFetch } from "../utils";

const url = "/products";

export const loader = async ({ request }) => {
  const req = await customFetch(url);
  console.log(req);
  const products = req.data.data;
  const meta = req.data.meta;
  console.log(meta);
  return { products, meta };
};

function Products() {
  return (
    <>
      <Filters />
      <ProductsContainer />
      <PaginationsContainer />
    </>
  );
}

export default Products;
